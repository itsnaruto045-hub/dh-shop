import { randomBytes } from "crypto";
import { Pool } from "pg";
import { 
  User as UserType, 
  Item as ItemType, 
  Transaction as TransactionType, 
  Ticket as TicketType, 
  InsertUser, 
  InsertItem, 
  InsertTransaction, 
  InsertTicket 
} from "@shared/schema";

export interface IStorage {
  getUser(id: string | number): Promise<UserType | undefined>;
  getUserByUsername(username: string): Promise<UserType | undefined>;
  createUser(user: InsertUser): Promise<UserType>;
  updateUserCredits(id: string, credits: number): Promise<UserType>;
  getUserCount(): Promise<number>;
  
  getItems(): Promise<ItemType[]>;
  getItem(id: string | number): Promise<ItemType | undefined>;
  createItem(item: InsertItem & { contents?: string[] }): Promise<ItemType>;
  deleteItem(id: string | number): Promise<void>;
  
  getTransactions(): Promise<TransactionType[]>;
  createTransaction(transaction: InsertTransaction & { userId: string }): Promise<TransactionType>;
  updateTransactionStatus(id: string | number, status: string): Promise<TransactionType>;
  updateTransactionAmount(id: string | number, amount: number): Promise<TransactionType>;
  
  getTickets(): Promise<TicketType[]>;
  createTicket(ticket: InsertTicket & { userId: string }): Promise<TicketType>;
  updateTicketReply(id: string | number, reply: string): Promise<TicketType>;
  
  createPurchase(userId: string, itemId: string, content: string): Promise<void>;
  hasPurchased(userId: string, itemId: string): Promise<boolean>;
  
  getRedeemCode(code: string): Promise<{ id: string; value: number; isUsed: boolean | null } | undefined>;
  markRedeemCodeUsed(id: string, userId: string): Promise<void>;
  generateRedeemCodes(value: number, count: number): Promise<{ id: string; code: string; value: number }[]>;
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Database Storage Implementation
export class DatabaseStorage implements IStorage {
  async getUser(id: string | number): Promise<UserType | undefined> {
    try {
      const result = await pool.query("SELECT * FROM users WHERE id = $1", [id]);
      if (result.rows.length === 0) return undefined;
      const row = result.rows[0];
      return {
        _id: String(row.id),
        id: String(row.id),
        username: row.username,
        password: row.password,
        role: row.role,
        credits: row.credits,
        createdAt: row.created_at,
      } as any;
    } catch {
      return undefined;
    }
  }

  async getUserByUsername(username: string): Promise<UserType | undefined> {
    try {
      const result = await pool.query("SELECT * FROM users WHERE username = $1", [username]);
      if (result.rows.length === 0) return undefined;
      const row = result.rows[0];
      return {
        _id: String(row.id),
        id: String(row.id),
        username: row.username,
        password: row.password,
        role: row.role,
        credits: row.credits,
        createdAt: row.created_at,
      } as any;
    } catch {
      return undefined;
    }
  }

  async createUser(insertUser: InsertUser): Promise<UserType> {
    const result = await pool.query(
      "INSERT INTO users (username, password, role, credits) VALUES ($1, $2, $3, $4) RETURNING *",
      [insertUser.username, insertUser.password, insertUser.role || "user", 0]
    );
    const row = result.rows[0];
    return {
      _id: String(row.id),
      id: String(row.id),
      username: row.username,
      password: row.password,
      role: row.role,
      credits: row.credits,
      createdAt: row.created_at,
    } as any;
  }

  async getUserCount(): Promise<number> {
    const result = await pool.query("SELECT COUNT(*) as count FROM users");
    return parseInt(result.rows[0].count, 10);
  }

  async updateUserCredits(id: string, credits: number): Promise<UserType> {
    const result = await pool.query(
      "UPDATE users SET credits = $1 WHERE id = $2 RETURNING *",
      [credits, id]
    );
    const row = result.rows[0];
    return {
      _id: String(row.id),
      id: String(row.id),
      username: row.username,
      password: row.password,
      role: row.role,
      credits: row.credits,
      createdAt: row.created_at,
    } as any;
  }

  async getItems(): Promise<ItemType[]> {
    const result = await pool.query("SELECT * FROM items ORDER BY created_at DESC");
    return result.rows.map(row => ({
      _id: String(row.id),
      id: String(row.id),
      title: row.title,
      description: row.description,
      price: row.price,
      type: row.type,
      content: row.content,
      createdAt: row.created_at,
    } as any));
  }

  async getItem(id: string | number): Promise<ItemType | undefined> {
    try {
      const result = await pool.query("SELECT * FROM items WHERE id = $1", [id]);
      if (result.rows.length === 0) return undefined;
      const row = result.rows[0];
      return {
        _id: String(row.id),
        id: String(row.id),
        title: row.title,
        description: row.description,
        price: row.price,
        type: row.type,
        content: row.content,
        createdAt: row.created_at,
      } as any;
    } catch {
      return undefined;
    }
  }

  async createItem(insertItem: InsertItem & { contents?: string[] }): Promise<ItemType> {
    const result = await pool.query(
      "INSERT INTO items (title, description, price, type, content) VALUES ($1, $2, $3, $4, $5) RETURNING *",
      [insertItem.title, insertItem.description, insertItem.price, insertItem.type, insertItem.content || null]
    );
    const row = result.rows[0];
    return {
      _id: String(row.id),
      id: String(row.id),
      title: row.title,
      description: row.description,
      price: row.price,
      type: row.type,
      content: row.content,
      createdAt: row.created_at,
    } as any;
  }

  async getTransactions(): Promise<TransactionType[]> {
    const result = await pool.query("SELECT * FROM transactions ORDER BY created_at DESC");
    return result.rows.map(row => ({
      _id: String(row.id),
      id: String(row.id),
      userId: String(row.user_id),
      transactionId: row.transaction_id,
      amount: row.amount,
      status: row.status,
      createdAt: row.created_at,
    } as any));
  }

  async createTransaction(transaction: InsertTransaction & { userId: string }): Promise<TransactionType> {
    const result = await pool.query(
      "INSERT INTO transactions (user_id, transaction_id, amount, status) VALUES ($1, $2, $3, $4) RETURNING *",
      [transaction.userId, transaction.transactionId, transaction.amount, "pending"]
    );
    const row = result.rows[0];
    return {
      _id: String(row.id),
      id: String(row.id),
      userId: String(row.user_id),
      transactionId: row.transaction_id,
      amount: row.amount,
      status: row.status,
      createdAt: row.created_at,
    } as any;
  }

  async updateTransactionStatus(id: string | number, status: string): Promise<TransactionType> {
    const result = await pool.query(
      "UPDATE transactions SET status = $1 WHERE id = $2 RETURNING *",
      [status, id]
    );
    const row = result.rows[0];
    return {
      _id: String(row.id),
      id: String(row.id),
      userId: String(row.user_id),
      transactionId: row.transaction_id,
      amount: row.amount,
      status: row.status,
      createdAt: row.created_at,
    } as any;
  }

  async updateTransactionAmount(id: string | number, amount: number): Promise<TransactionType> {
    const result = await pool.query(
      "UPDATE transactions SET amount = $1 WHERE id = $2 RETURNING *",
      [amount, id]
    );
    const row = result.rows[0];
    return {
      _id: String(row.id),
      id: String(row.id),
      userId: String(row.user_id),
      transactionId: row.transaction_id,
      amount: row.amount,
      status: row.status,
      createdAt: row.created_at,
    } as any;
  }

  async getTickets(): Promise<TicketType[]> {
    const result = await pool.query("SELECT * FROM tickets ORDER BY created_at DESC");
    return result.rows.map(row => ({
      _id: String(row.id),
      id: String(row.id),
      userId: String(row.user_id),
      subject: row.subject,
      message: row.message,
      status: row.status,
      reply: row.reply,
      createdAt: row.created_at,
    } as any));
  }

  async createTicket(ticket: InsertTicket & { userId: string }): Promise<TicketType> {
    const result = await pool.query(
      "INSERT INTO tickets (user_id, subject, message, status) VALUES ($1, $2, $3, $4) RETURNING *",
      [ticket.userId, ticket.subject, ticket.message, "open"]
    );
    const row = result.rows[0];
    return {
      _id: String(row.id),
      id: String(row.id),
      userId: String(row.user_id),
      subject: row.subject,
      message: row.message,
      status: row.status,
      reply: row.reply,
      createdAt: row.created_at,
    } as any;
  }

  async updateTicketReply(id: string | number, reply: string): Promise<TicketType> {
    const result = await pool.query(
      "UPDATE tickets SET reply = $1, status = $2 WHERE id = $3 RETURNING *",
      [reply, "closed", id]
    );
    const row = result.rows[0];
    return {
      _id: String(row.id),
      id: String(row.id),
      userId: String(row.user_id),
      subject: row.subject,
      message: row.message,
      status: row.status,
      reply: row.reply,
      createdAt: row.created_at,
    } as any;
  }

  async createPurchase(userId: string, itemId: string, content: string): Promise<void> {
    await pool.query(
      "INSERT INTO purchases (user_id, item_id, content_delivered) VALUES ($1, $2, $3)",
      [userId, itemId, content]
    );
  }

  async hasPurchased(userId: string, itemId: string): Promise<boolean> {
    const result = await pool.query(
      "SELECT COUNT(*) as count FROM purchases WHERE user_id = $1 AND item_id = $2",
      [userId, itemId]
    );
    return parseInt(result.rows[0].count, 10) > 0;
  }

  async getRedeemCode(code: string) {
    try {
      const result = await pool.query("SELECT * FROM redeem_codes WHERE code = $1", [code]);
      if (result.rows.length === 0) return undefined;
      const row = result.rows[0];
      return { id: String(row.id), value: row.value, isUsed: row.is_used };
    } catch {
      return undefined;
    }
  }

  async markRedeemCodeUsed(id: string, userId: string): Promise<void> {
    await pool.query(
      "UPDATE redeem_codes SET is_used = true, used_by = $1 WHERE id = $2",
      [userId, id]
    );
  }

  async deleteItem(id: string | number): Promise<void> {
    await pool.query("DELETE FROM items WHERE id = $1", [id]);
  }

  async generateRedeemCodes(value: number, count: number): Promise<{ id: string; code: string; value: number }[]> {
    const codes = [];
    for (let i = 0; i < count; i++) {
      const code = randomBytes(8).toString('hex').toUpperCase();
      const result = await pool.query(
        "INSERT INTO redeem_codes (code, value) VALUES ($1, $2) RETURNING id, code, value",
        [code, value]
      );
      const row = result.rows[0];
      codes.push({ id: String(row.id), code: row.code, value: row.value });
    }
    return codes;
  }
}

export const storage = new DatabaseStorage();
